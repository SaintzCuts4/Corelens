# CoreLens
แอปดูสเปกเครื่อง: รุ่น / CPU (ความเร็วสดแต่ละคอร์) / GPU / อุณหภูมิ / แบตเตอรี่ / เซนเซอร์
แตะการ์ดเพื่อคัดลอกข้อมูล

## วิธีได้ไฟล์ APK
### A) Android Studio (บนคอม)
1. เปิดโฟลเดอร์นี้ -> รอ Gradle sync
2. เมนู Build > Build Bundle(s) / APK(s) > Build APK(s)
3. ไฟล์อยู่ที่ app/build/outputs/apk/debug/app-debug.apk

### B) GitHub Actions (ทำจากมือถือ/เบราว์เซอร์ได้ ไม่ต้องลงโปรแกรม)
1. สร้าง repo ใหม่บน github.com แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (รวมโฟลเดอร์ .github)
2. แท็บ Actions -> Build APK -> Run workflow
3. รอประมาณ 3-5 นาที แล้วดาวน์โหลด CoreLens-apk จากหน้าผลลัพธ์ (Artifacts)
