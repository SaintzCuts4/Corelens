# CoreLens
แอปดูสเปกเครื่อง: รุ่น / CPU (ความเร็วสดแต่ละคอร์) / GPU / อุณหภูมิ / แบตเตอรี่ / เซนเซอร์
กดการ์ดค้าง 1 วินาที = เมนู คัดลอก / แชร์

## ได้ไฟล์ APK ผ่าน GitHub Actions
1. อัปโหลด CoreLens.zip + .github/workflows/build.yml ขึ้น repo
2. Actions -> Build APK -> Run workflow
3. ดาวน์โหลด CoreLens-apk จากหน้า Summary (ไฟล์ app-release.apk)
