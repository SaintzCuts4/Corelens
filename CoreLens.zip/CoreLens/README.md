# Apex Space
แอป Game Space + Overlay สไตล์เกมมิ่ง
- ฉากเปิดแอป (intro effect)
- Overlay: Crosshair / HUD ข้อมูลเครื่อง / แผงขอบจอเปิดระหว่างเล่นเกม
- Game Library: แตะเกม = เปิดเกมพร้อม overlay
- Info: แบต, อุณหภูมิ, RAM, ping, CPU, GPU

## Build
อัปโหลด CoreLens.zip + .github/workflows/build.yml ขึ้น repo -> Actions -> Build APK -> Run workflow
ได้ไฟล์ app-release.apk จาก Artifacts
