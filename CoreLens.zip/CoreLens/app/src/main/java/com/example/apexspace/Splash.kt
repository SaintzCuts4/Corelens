package com.example.apexspace

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

private fun endFade(t: Float): Float = (1f - ((t - 0.88f) / 0.12f)).coerceIn(0f, 1f)

// ฉากเปิดแอป: แสงแดง + เส้นสแกน + ตัวอักษรกลิตช์ + แถบโหลด
@Composable
fun Splash(onReveal: () -> Unit, onDone: () -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        p.animateTo(0.85f, tween(2300, easing = LinearEasing))
        onReveal()
        p.animateTo(1f, tween(400, easing = LinearEasing))
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = endFade(p.value) }
            .background(Color(0xFF040405))
            .pointerInput(Unit) {
                detectTapGestures {
                    onReveal()
                    onDone()
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) { drawSplash(p.value) }
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GlitchTitle("APEX SPACE") { p.value }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.graphicsLayer { alpha = ((p.value - 0.5f) / 0.15f).coerceIn(0f, 1f) }) {
                Txt("GAME SPACE  //  OVERLAY SYSTEM", 12, Dim)
            }
            Spacer(Modifier.height(36.dp))
            Canvas(Modifier.width(220.dp).height(4.dp)) {
                val prog = FastOutSlowInEasing.transform(p.value.coerceIn(0f, 1f))
                drawRect(Color.White.copy(alpha = 0.10f), Offset.Zero, Size(size.width, size.height))
                drawRect(
                    Brush.horizontalGradient(listOf(Accent, Accent2), endX = size.width),
                    Offset.Zero,
                    Size(size.width * prog, size.height)
                )
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.graphicsLayer { alpha = if (((p.value * 12f).toInt() % 2) == 0) 1f else 0.35f }) {
                Txt("INITIALIZING...", 11, Dim)
            }
        }
    }
}

@Composable
private fun GlitchTitle(text: String, progress: () -> Float) {
    Box {
        TitleLayer(text, Color(0xFFFF2442), progress, 1f)
        TitleLayer(text, Color(0xFF00E5FF), progress, -1f)
        TitleLayer(text, Color.White, progress, 0f)
    }
}

@Composable
private fun TitleLayer(text: String, color: Color, progress: () -> Float, dir: Float) {
    Row {
        text.forEachIndexed { i, ch ->
            Text(
                text = ch.toString(),
                color = color,
                fontSize = 44.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Italic,
                letterSpacing = 2.sp,
                modifier = Modifier.graphicsLayer {
                    val t = progress()
                    val a = ((t - (0.10f + i * 0.035f)) / 0.08f).coerceIn(0f, 1f)
                    val glitch = dir != 0f && t >= 0.25f && t <= 0.62f
                    translationX = if (glitch) sin(t * 160f + i) * 7.dp.toPx() * dir else 0f
                    translationY = (1f - a) * 18.dp.toPx()
                    alpha = if (dir != 0f && !glitch) 0f else a * endFade(t)
                }
            )
        }
    }
}

private fun DrawScope.drawSplash(t: Float) {
    val w = size.width
    val h = size.height
    val fade = endFade(t)

    // แสงแดงกลางจอ
    val glowA = (t * 2.2f).coerceIn(0f, 1f) * 0.55f * fade
    val glowR = max(w, h) * (0.25f + 0.55f * t)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Accent.copy(alpha = glowA), Color.Transparent),
            center = Offset(w / 2f, h / 2f),
            radius = glowR
        ),
        radius = glowR,
        center = Offset(w / 2f, h / 2f)
    )

    // เส้นเฉียงพุ่งผ่านจอ
    val sw = 2.dp.toPx()
    for (i in 0 until 7) {
        val sp = 0.6f + i * 0.15f
        val ph = (t * sp + i * 0.13f) % 1f
        val x = -w * 0.3f + ph * w * 1.6f
        val y0 = h * (0.08f + i * 0.13f)
        val a = (1f - abs(ph - 0.5f) * 1.8f).coerceAtLeast(0f) * 0.6f * fade
        drawLine(
            color = Accent.copy(alpha = a),
            start = Offset(x, y0),
            end = Offset(x + 150.dp.toPx(), y0 - 38.dp.toPx()),
            strokeWidth = sw
        )
    }

    // เส้นสแกนกวาดลง
    val sy = h * ((t * 1.7f) % 1f)
    val band = 46.dp.toPx()
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.Transparent, Accent.copy(alpha = 0.22f * fade), Color.Transparent),
            startY = sy - band,
            endY = sy + band
        ),
        topLeft = Offset(0f, sy - band),
        size = Size(w, band * 2f)
    )

    // วงเล็บมุมจอ
    val e = FastOutSlowInEasing.transform((t * 3f).coerceIn(0f, 1f))
    val m = 26.dp.toPx()
    val len = 56.dp.toPx() * e
    val cw = 2.5.dp.toPx()
    val c = Accent.copy(alpha = fade)
    fun corner(x: Float, y: Float, sx: Float, sy2: Float) {
        drawLine(c, Offset(x, y), Offset(x + sx * len, y), cw)
        drawLine(c, Offset(x, y), Offset(x, y + sy2 * len), cw)
    }
    corner(m, m, 1f, 1f)
    corner(w - m, m, -1f, 1f)
    corner(m, h - m, 1f, -1f)
    corner(w - m, h - m, -1f, -1f)
}
