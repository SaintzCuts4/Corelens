package com.example.apexspace

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class LiveStats(
    val level: Int,
    val tempC: Float,
    val currentMa: Int?,
    val voltMv: Int,
    val charging: Boolean,
    val ramPct: Int,
    val ramUsedGb: Float,
    val ramTotalGb: Float,
    val cpuMaxMhz: Long?,
    val hz: Int
)

object Stats {
    fun read(ctx: Context, coreIds: List<Int>): LiveStats {
        val b = Power.battery(ctx)
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val total = mi.totalMem.toDouble().coerceAtLeast(1.0)
        val used = total - mi.availMem
        val gb = 1024.0 * 1024.0 * 1024.0
        val freqs = coreIds.mapNotNull { Cpu.curKhz(it) }.filter { it > 0 }
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val hz = dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.roundToInt() ?: 0
        return LiveStats(
            level = b.level,
            tempC = b.tempC,
            currentMa = b.currentMa,
            voltMv = b.voltageMv,
            charging = b.charging,
            ramPct = (used * 100 / total).roundToInt(),
            ramUsedGb = (used / gb).toFloat(),
            ramTotalGb = (total / gb).toFloat(),
            cpuMaxMhz = freqs.maxOrNull()?.let { it / 1000 },
            hz = hz
        )
    }
}

val PING_TARGETS = listOf("1.1.1.1" to 443, "8.8.8.8" to 443, "www.google.com" to 443)
val PING_NAMES = listOf("CLOUDFLARE", "GOOGLE DNS", "GOOGLE")

object Ping {
    // วัดเวลาเชื่อมต่อ TCP (มิลลิวินาที) ถ้าไม่ได้คืน null
    fun measure(target: Int): Int? {
        val t = PING_TARGETS[target.coerceIn(0, PING_TARGETS.size - 1)]
        return try {
            val s = Socket()
            val t0 = System.nanoTime()
            s.connect(InetSocketAddress(t.first, t.second), 1500)
            val ms = ((System.nanoTime() - t0) / 1_000_000).toInt()
            s.close()
            ms
        } catch (e: Exception) {
            null
        }
    }
}

// รายการข้อมูลที่จะโชว์บน HUD (ชื่อ -> ค่า) ใช้ร่วมกันทั้งตัว overlay และหน้าตัวอย่างในแอป
fun hudItems(h: Hud, s: LiveStats?, ping: Int?): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    if (s == null) return out
    if (h.battery) out.add("BAT" to (s.level.toString() + "%" + if (s.charging) "+" else ""))
    if (h.temp) out.add("TEMP" to (Fmt.f1(s.tempC) + "°C"))
    if (h.power) {
        val ma = s.currentMa
        out.add("PWR" to (if (ma == null) "--" else Fmt.f1(abs(ma) * s.voltMv / 1_000_000f) + "W"))
    }
    if (h.ram) out.add("RAM" to (s.ramPct.toString() + "%"))
    if (h.cpu) out.add("CPU" to (if (s.cpuMaxMhz == null) "N/A" else s.cpuMaxMhz.toString() + "MHz"))
    if (h.ping) out.add("PING" to (if (ping == null) "--" else ping.toString() + "ms"))
    if (h.hz) out.add("HZ" to s.hz.toString())
    if (h.clock) out.add("TIME" to SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
    return out
}
