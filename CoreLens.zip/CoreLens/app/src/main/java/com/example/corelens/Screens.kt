package com.example.corelens

import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun CoreLensApp() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = remember {
        listOf(
            Tab("📱", "เครื่อง"), Tab("🧠", "CPU"), Tab("🎮", "GPU"),
            Tab("🌡️", "อุณหภูมิ"), Tab("🔋", "แบต")
        )
    }
    Box(Modifier.fillMaxSize().background(Bg)) {
        // เปลี่ยนหน้าด้วยการจางเข้า-ออกอย่างเดียว (เบาที่สุด ไม่กระตุก)
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(90)) },
            label = "tabs"
        ) { t ->
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .statusBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (t) {
                    0 -> DeviceScreen()
                    1 -> CpuScreen()
                    2 -> GpuScreen()
                    3 -> TempScreen()
                    else -> BatteryScreen()
                }
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)
        ) { FloatingNav(tab, tabs) { tab = it } }
    }
}

// อ่านข้อมูลหนัก ๆ ทั้งหมดใน background thread เพื่อไม่ให้หน้าจอสะดุดตอนเปิดหน้า

@Composable
fun DeviceScreen() {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("…") }
    var groups by remember { mutableStateOf<List<Pair<String, Rows>>>(emptyList()) }
    var sensors by remember { mutableStateOf<Rows>(emptyList()) }
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val r = withContext(Dispatchers.IO) {
            Triple(Info.marketName(ctx), Info.deviceGroups(ctx), Info.sensors(ctx))
        }
        name = r.first
        groups = r.second
        sensors = r.third
        ready = true
    }
    Reveal(0) {
        Column {
            Hero("📱", name, "Android ${Build.VERSION.RELEASE} • ${Build.MODEL}")
            Spacer(Modifier.height(8.dp))
            Txt("กดการ์ดค้าง 1 วินาที เพื่อคัดลอกหรือแชร์", 12, Dim, modifier = Modifier.padding(start = 6.dp))
        }
    }
    if (ready) {
        groups.forEachIndexed { i, g -> Reveal(i + 1) { InfoCard(g.first, g.second) } }
        Reveal(groups.size + 1) { ExpandCard("เซนเซอร์ (${sensors.size})", sensors) }
    }
}

private data class CpuUi(val cores: List<Core>, val soc: String, val summary: String, val governor: String?)

@Composable
fun CpuScreen() {
    var ui by remember { mutableStateOf<CpuUi?>(null) }
    var cur by remember { mutableStateOf<List<Long?>>(emptyList()) }
    LaunchedEffect(Unit) {
        val d = withContext(Dispatchers.IO) {
            val c = Cpu.cores()
            CpuUi(
                c, Cpu.soc(),
                c.groupingBy { it.name }.eachCount().entries.joinToString("  •  ") { "${it.value}× ${it.key}" },
                Cpu.governor()
            )
        }
        ui = d
        while (true) {
            cur = withContext(Dispatchers.IO) { d.cores.map { Cpu.curKhz(it.id) } }
            delay(1000)
        }
    }
    val u = ui
    if (u != null) {
        Reveal(0) { Hero("🧠", u.soc, "${u.cores.size} คอร์ • ${Build.SUPPORTED_ABIS.firstOrNull() ?: ""}") }
        Reveal(1) {
            InfoCard(
                "ภาพรวม",
                listOf(
                    "SoC" to u.soc,
                    "จำนวนคอร์" to "${u.cores.size}",
                    "โครงสร้าง" to u.summary,
                    "สถาปัตยกรรม" to Build.SUPPORTED_ABIS.joinToString(", "),
                    "Governor" to (u.governor ?: "อ่านไม่ได้")
                )
            )
        }
        Reveal(2) {
            val speeds = u.cores.mapIndexed { i, c ->
                "CPU${c.id} ${c.name}: " + (cur.getOrNull(i)?.let { "${it / 1000} MHz" } ?: "-")
            }.joinToString("\n")
            ActionCard("ความเร็ว CPU", speeds, Modifier.fillMaxWidth()) {
                SectionTitle("ความเร็วสดแต่ละคอร์")
                u.cores.forEachIndexed { i, c -> CoreBar(c, cur.getOrNull(i)) }
                if (cur.isNotEmpty() && cur.all { it == null }) {
                    Spacer(Modifier.height(6.dp))
                    Txt("เครื่องนี้ไม่อนุญาตให้แอปทั่วไปอ่านความเร็วสดของ CPU", 12, Dim)
                }
            }
        }
    }
}

@Composable
fun GpuScreen() {
    val ctx = LocalContext.current
    var g by remember { mutableStateOf<GpuData?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var freq by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(Unit) {
        g = withContext(Dispatchers.Default) { Gpu.query() }
        loaded = true
        while (true) {
            freq = withContext(Dispatchers.IO) { Gpu.freqHz() }
            delay(1000)
        }
    }
    val gd = g
    Reveal(0) {
        Hero(
            "🎮",
            gd?.renderer ?: if (loaded) "ไม่ทราบรุ่น GPU" else "กำลังอ่านข้อมูล…",
            gd?.vendor ?: ""
        )
    }
    if (gd != null) {
        Reveal(1) {
            InfoCard(
                "ข้อมูล GPU",
                listOf(
                    "Renderer" to gd.renderer,
                    "Vendor" to gd.vendor,
                    "OpenGL ES (ไดรเวอร์)" to gd.version,
                    "GLES ที่รองรับ" to Gpu.glEsSupported(ctx),
                    "GLSL" to gd.glsl,
                    "Vulkan" to Gpu.vulkan(ctx),
                    "Texture สูงสุด" to "${gd.maxTex} px",
                    "จำนวน Extensions" to "${gd.extCount}"
                )
            )
        }
    }
    Reveal(2) {
        val f = freq
        if (f != null) InfoCard("ความถี่ GPU ตอนนี้", listOf("ความเร็ว" to "${f / 1_000_000} MHz"))
        else NoteCard("ความถี่ GPU ตอนนี้", "เครื่องนี้ไม่อนุญาตให้แอปทั่วไปอ่านความถี่ GPU")
    }
}

fun tempColor(c: Float): Color = when {
    c < 35f -> Good
    c < 42f -> Warm
    else -> Hot
}

@Composable
fun TempScreen() {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<ThermalSnap?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            snap = withContext(Dispatchers.IO) { Power.snapshot(ctx) }
            delay(2000)
        }
    }
    val s = snap
    val t = s?.battery?.tempC ?: 0f
    Reveal(0) {
        ActionCard("อุณหภูมิแบตเตอรี่", "${Fmt.f1(t)}°C", Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                RingGauge(
                    fraction = t / 60f,
                    color = tempColor(t),
                    big = if (s == null) "…" else "${Fmt.f1(t)}°C",
                    small = "แบตเตอรี่"
                )
            }
        }
    }
    if (s != null) {
        Reveal(1) {
            InfoCard(
                "สถานะความร้อนของระบบ",
                listOf(
                    "ระดับ" to s.status,
                    "ใกล้ขีดจำกัด" to (s.headroom?.let { "${(it * 100).toInt()}%" } ?: "ไม่มีข้อมูล")
                )
            )
        }
        Reveal(2) {
            if (s.zones.isNotEmpty()) {
                InfoCard(
                    "เซนเซอร์ความร้อน (CPU/GPU/อื่น ๆ)",
                    s.zones.sortedByDescending { it.second }.map { it.first to "${Fmt.f1(it.second)}°C" }
                )
            } else {
                NoteCard(
                    "เซนเซอร์ CPU / GPU",
                    "Android รุ่นใหม่ไม่ให้แอปทั่วไปอ่านอุณหภูมิ CPU/GPU โดยตรง " +
                        "จึงแสดงอุณหภูมิแบตเตอรี่และสถานะความร้อนของระบบแทน"
                )
            }
        }
    }
}

@Composable
fun BatteryScreen() {
    val ctx = LocalContext.current
    var b by remember { mutableStateOf<BatteryData?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            b = withContext(Dispatchers.IO) { Power.battery(ctx) }
            delay(2000)
        }
    }
    val d = b
    val lvl = d?.level ?: 0
    Reveal(0) {
        ActionCard("แบตเตอรี่", "$lvl%", Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                RingGauge(
                    fraction = lvl / 100f,
                    color = if (lvl < 20) Hot else if (lvl < 50) Warm else Good,
                    big = if (d == null) "…" else "$lvl%",
                    small = d?.status ?: ""
                )
            }
        }
    }
    if (d != null) {
        Reveal(1) {
            InfoCard(
                "รายละเอียดแบตเตอรี่",
                listOf(
                    "สถานะ" to d.status,
                    "สุขภาพ" to d.health,
                    "แหล่งไฟ" to d.plugged,
                    "แรงดัน" to "${d.voltageMv} mV",
                    "กระแสขณะนี้" to (d.currentMa?.let { "$it mA" } ?: "อ่านไม่ได้"),
                    "อุณหภูมิ" to "${Fmt.f1(d.tempC)}°C",
                    "เทคโนโลยี" to d.tech
                )
            )
        }
    }
}
