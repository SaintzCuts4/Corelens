package com.example.apexspace

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.abs

private val RED = 0xFFFF2442.toInt()
private val PANEL_BG = 0xF2090A0D.toInt()

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.apexspace.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val pingExec = Executors.newSingleThreadExecutor()

    private var cross: CrosshairView? = null
    private var hudText: TextView? = null
    private var handle: View? = null
    private var panel: LinearLayout? = null
    private var panelStats: TextView? = null
    private var panelRight = false

    private var curHud = Hud()
    private var curCross = Cross()
    private var coreIds: List<Int> = emptyList()
    @Volatile private var ping: Int? = null
    @Volatile private var lastStats: LiveStats? = null

    private val applyRunnable = Runnable { applySettings() }
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        main.removeCallbacks(applyRunnable)
        main.post(applyRunnable)
    }

    private val tick = object : Runnable {
        override fun run() {
            exec.execute {
                try {
                    val s = Stats.read(this@OverlayService, coreIds)
                    main.post {
                        lastStats = s
                        renderHud()
                        renderPanel()
                    }
                } catch (e: Exception) { /* ignore */ }
            }
            main.postDelayed(this, curHud.intervalSec.coerceIn(1, 10) * 1000L)
        }
    }

    private val pingTick = object : Runnable {
        override fun run() {
            if (curHud.ping || panel != null) {
                val target = curHud.pingTarget
                pingExec.execute { ping = Ping.measure(target) }
            }
            main.postDelayed(this, 3000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Store.prefs(this)
        OverlayState.running = true
        exec.execute { coreIds = Cpu.cores().map { it.id } }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        applySettings()
        main.post(tick)
        main.post(pingTick)
    }

    override fun onDestroy() {
        OverlayState.running = false
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        main.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            removeCross()
            removeHud()
            removeHandle()
            panel?.let { runCatching { wm.removeView(it) } }
            panel = null
        }
        exec.shutdownNow()
        pingExec.shutdownNow()
        super.onDestroy()
    }

    // ───────── notification ─────────
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("apex", "Apex Space", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, "apex")
            .setContentTitle("Apex Space overlay กำลังทำงาน")
            .setContentText("Crosshair / HUD / แผงควบคุมเกม")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(0, "ปิด Overlay", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ───────── helpers ─────────
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun mk(w: Int, h: Int, extra: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or extra,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    // ───────── apply settings ─────────
    private fun applySettings() {
        if (!::wm.isInitialized) return
        val c = Store.loadCross(this)
        val h = Store.loadHud(this)
        curCross = c
        curHud = h

        // crosshair
        if (c.on) {
            if (cross == null) {
                val v = CrosshairView(this)
                v.cfg = c
                runCatching {
                    wm.addView(v, mk(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE))
                }
                cross = v
            } else {
                cross?.cfg = c
            }
        } else {
            removeCross()
        }

        // HUD
        if (h.on) {
            val tv = hudText ?: makeHud().also {
                runCatching { wm.addView(it, hudParams(h)) }
                hudText = it
            }
            runCatching { wm.updateViewLayout(tv, hudParams(h)) }
            tv.textSize = h.textSize.toFloat()
            tv.background = AngularBg(
                Color.argb((h.opacity.coerceIn(20, 100) * 255) / 100, 0, 0, 0),
                RED, dp(8).toFloat(), dp(1).toFloat()
            )
            renderHud()
        } else {
            removeHud()
        }

        // แถบขอบจอ
        if (h.handle) {
            val v = handle
            if (v == null) addHandle(h) else runCatching { wm.updateViewLayout(v, handleParams(h)) }
        } else {
            removeHandle()
            closePanel()
        }
    }

    private fun removeCross() {
        cross?.let { runCatching { wm.removeView(it) } }
        cross = null
    }

    private fun removeHud() {
        hudText?.let { runCatching { wm.removeView(it) } }
        hudText = null
    }

    private fun removeHandle() {
        handle?.let { runCatching { wm.removeView(it) } }
        handle = null
    }

    // ───────── HUD ─────────
    private fun makeHud(): TextView = TextView(this).apply {
        typeface = Typeface.MONOSPACE
        setTextColor(Color.WHITE)
        setPadding(dp(12), dp(6), dp(12), dp(6))
    }

    private fun hudParams(h: Hud): WindowManager.LayoutParams {
        val lp = mk(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        lp.gravity = when (h.pos) {
            1 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            2 -> Gravity.TOP or Gravity.END
            3 -> Gravity.BOTTOM or Gravity.START
            4 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            5 -> Gravity.BOTTOM or Gravity.END
            else -> Gravity.TOP or Gravity.START
        }
        lp.x = dp(8)
        lp.y = dp(8)
        return lp
    }

    private fun buildHud(items: List<Pair<String, String>>, vertical: Boolean, pad: Boolean): CharSequence {
        val sb = SpannableStringBuilder()
        items.forEachIndexed { i, kv ->
            if (i > 0) sb.append(if (vertical) "\n" else "   ")
            val start = sb.length
            sb.append(if (pad) kv.first.padEnd(5) else kv.first).append(' ')
            sb.setSpan(ForegroundColorSpan(RED), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(kv.second)
        }
        return sb
    }

    private fun renderHud() {
        val tv = hudText ?: return
        val s = lastStats ?: return
        tv.text = buildHud(hudItems(curHud, s, ping), curHud.vertical, curHud.vertical)
    }

    private fun renderPanel() {
        val tv = panelStats ?: return
        val s = lastStats ?: return
        tv.text = buildHud(hudItems(Hud(clock = true), s, ping), true, true)
    }

    // ───────── แถบขอบจอ (เปิดแผงควบคุม) ─────────
    private fun handleParams(h: Hud): WindowManager.LayoutParams {
        val saved = Store.handleY(this)
        val lp = mk(dp(14), dp(86), 0)
        lp.gravity = Gravity.TOP or (if (h.handleRight) Gravity.END else Gravity.START)
        lp.x = 0
        lp.y = if (saved >= 0) saved else resources.displayMetrics.heightPixels / 2 - dp(43)
        return lp
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addHandle(h: Hud) {
        val lp = handleParams(h)
        val v = View(this)
        v.background = AngularBg(0xCCFF2442.toInt(), 0x00000000, dp(5).toFloat(), 0f)
        v.alpha = 0.7f
        v.setOnTouchListener(object : View.OnTouchListener {
            var sy = 0
            var ty = 0f
            var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sy = lp.y
                        ty = e.rawY
                        moved = false
                        view.alpha = 1f
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.y = sy + dy
                            runCatching { wm.updateViewLayout(view, lp) }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        view.alpha = 0.7f
                        if (moved) Store.saveHandleY(this@OverlayService, lp.y) else openPanel()
                    }
                    MotionEvent.ACTION_CANCEL -> view.alpha = 0.7f
                }
                return true
            }
        })
        runCatching { wm.addView(v, lp) }
        handle = v
    }

    // ───────── แผงควบคุมระหว่างเล่นเกม ─────────
    @SuppressLint("ClickableViewAccessibility")
    private fun btn(label: String, filled: Boolean, onClick: (TextView) -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12f
        tv.gravity = Gravity.CENTER
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(8), dp(10), dp(8), dp(10))
        tv.background = AngularBg(if (filled) 0xCCB0001E.toInt() else 0x33FFFFFF, RED, dp(8).toFloat(), dp(1).toFloat())
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }
            false
        }
        tv.setOnClickListener { onClick(tv) }
        return tv
    }

    private fun cell(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        views.forEach { r.addView(it, cell()) }
        return r
    }

    private fun crossLabel(): String = "CROSSHAIR  " + (if (Store.loadCross(this).on) "ON" else "OFF")
    private fun hudLabel(): String = "HUD  " + (if (Store.loadHud(this).on) "ON" else "OFF")

    private fun editCross(f: (Cross) -> Cross) {
        Store.saveCross(this, f(Store.loadCross(this)))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun openPanel() {
        if (panel != null) return
        panelRight = curHud.handleRight

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(12), dp(14), dp(12))
        root.background = AngularBg(PANEL_BG, RED, dp(16).toFloat(), dp(1).toFloat())
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) {
                closePanel()
                true
            } else false
        }

        val title = TextView(this)
        title.text = "APEX SPACE"
        title.setTextColor(RED)
        title.textSize = 17f
        title.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        title.letterSpacing = 0.1f
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(btn("✕", false) { closePanel() })
        root.addView(head)

        val st = TextView(this)
        st.typeface = Typeface.MONOSPACE
        st.setTextColor(Color.WHITE)
        st.textSize = 12f
        st.setPadding(0, dp(10), 0, dp(8))
        st.text = "..."
        panelStats = st
        root.addView(st)

        root.addView(row(
            btn(crossLabel(), false) { tv -> editCross { it.copy(on = !it.on) }; tv.text = crossLabel() },
            btn(hudLabel(), false) { tv ->
                val h = Store.loadHud(this)
                Store.saveHud(this, h.copy(on = !h.on))
                tv.text = hudLabel()
            }
        ))
        root.addView(row(
            btn("◀ STYLE", false) { editCross { it.copy(style = (it.style + CROSS_NAMES.size - 1) % CROSS_NAMES.size) } },
            btn("STYLE ▶", false) { editCross { it.copy(style = (it.style + 1) % CROSS_NAMES.size) } }
        ))
        root.addView(row(
            btn("COLOR", false) {
                editCross { c ->
                    val i = CROSS_COLORS.indexOf(c.color)
                    c.copy(color = CROSS_COLORS[(i + 1) % CROSS_COLORS.size])
                }
            },
            btn("SIZE −", false) { editCross { it.copy(size = (it.size - 2).coerceAtLeast(4)) } },
            btn("SIZE +", false) { editCross { it.copy(size = (it.size + 2).coerceAtMost(60)) } }
        ))
        root.addView(row(
            btn("◀", false) { editCross { it.copy(offX = (it.offX - 1).coerceAtLeast(-150)) } },
            btn("▲", false) { editCross { it.copy(offY = (it.offY - 1).coerceAtLeast(-150)) } },
            btn("▼", false) { editCross { it.copy(offY = (it.offY + 1).coerceAtMost(150)) } },
            btn("▶", false) { editCross { it.copy(offX = (it.offX + 1).coerceAtMost(150)) } }
        ))
        root.addView(row(btn("■  STOP OVERLAY", true) { stopSelf() }))

        val lp = mk(dp(300), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH)
        lp.gravity = Gravity.CENTER_VERTICAL or (if (panelRight) Gravity.END else Gravity.START)
        lp.x = dp(6)
        runCatching { wm.addView(root, lp) }
        panel = root
        renderPanel()

        root.alpha = 0f
        root.post {
            root.translationX = (if (panelRight) 1f else -1f) * root.width
            root.alpha = 1f
            root.animate().translationX(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closePanel() {
        val p = panel ?: return
        panel = null
        panelStats = null
        p.animate()
            .translationX((if (panelRight) 1f else -1f) * p.width)
            .setDuration(170)
            .withEndAction { runCatching { wm.removeView(p) } }
            .start()
    }
}
