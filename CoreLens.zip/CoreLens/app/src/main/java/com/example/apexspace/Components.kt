package com.example.apexspace

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ───────── สี ─────────
val Bg = Color(0xFF060709)
val CardBg = Color(0xFF101114)
val Accent = Color(0xFFFF2442)
val Accent2 = Color(0xFFFF7A18)
val Good = Color(0xFF3DDC97)
val Warm = Color(0xFFFFB84D)
val Hot = Color(0xFFFF3B3B)
val Dim = Color(0xFF8E939E)

// ต้องกดค้างกี่มิลลิวินาทีถึงจะขึ้นเมนู คัดลอก/แชร์
private const val HOLD_MS = 1000

@Composable
fun ApexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = CardBg),
        content = content
    )
}

@Composable
fun Txt(
    text: String,
    size: Int = 14,
    color: Color = Color.White,
    bold: Boolean = false,
    modifier: Modifier = Modifier,
    align: TextAlign? = null
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = align
    )
}

fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    if (Build.VERSION.SDK_INT < 33) {
        Toast.makeText(ctx, "คัดลอก \"$label\" แล้ว", Toast.LENGTH_SHORT).show()
    }
}

fun shareText(ctx: Context, title: String, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, title)
        putExtra(Intent.EXTRA_TEXT, "$title\n$text")
    }
    ctx.startActivity(Intent.createChooser(i, "แชร์"))
}

private class Flag { var done = false }

// ───────── การ์ด: แตะ = ย่อ-เด้ง + แสงกระจาย / กดค้าง 1 วิ = แถบเต็ม แล้วขึ้นเมนู ─────────
// ทุกอย่างที่เคลื่อนไหวอ่านค่าในขั้นตอนวาด (draw) เท่านั้น จึงไม่ทำให้ต้องคำนวณ UI ใหม่ทุกเฟรม
@Composable
fun GlowCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    padding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)
    val flag = remember { Flag() }
    var pressed by remember { mutableStateOf(false) }
    var touch by remember { mutableStateOf(Offset.Zero) }
    val ripple = remember { Animatable(0f) }
    val hold = remember { Animatable(0f) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 600f),
        label = "press"
    )
    val shape = remember { CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp) }
    val borderBrush = remember {
        Brush.linearGradient(listOf(Accent.copy(alpha = 0.55f), Accent2.copy(alpha = 0.10f)))
    }

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(CardBg)
            .border(1.dp, borderBrush, shape)
            .drawBehind {
                val p = ripple.value
                if (p > 0f) {
                    val r = (size.maxDimension * 1.2f * p).coerceAtLeast(1f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Accent.copy(alpha = 0.30f * (1f - p)), Color.Transparent),
                            center = touch,
                            radius = r
                        ),
                        radius = r,
                        center = touch
                    )
                }
                val h = hold.value
                if (h > 0.12f) {
                    val bar = 4.dp.toPx()
                    drawRect(
                        brush = Brush.horizontalGradient(listOf(Accent, Accent2), endX = size.width),
                        topLeft = Offset(0f, size.height - bar),
                        size = Size(size.width * h, bar)
                    )
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { o ->
                        touch = o
                        pressed = true
                        flag.done = false
                        scope.launch {
                            ripple.snapTo(0f)
                            ripple.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
                        }
                        val job = if (longClick != null) {
                            scope.launch {
                                hold.snapTo(0f)
                                hold.animateTo(1f, tween(HOLD_MS, easing = LinearEasing))
                                flag.done = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                longClick?.invoke()
                            }
                        } else null
                        tryAwaitRelease()
                        job?.cancel()
                        pressed = false
                        scope.launch { hold.animateTo(0f, tween(180)) }
                    },
                    onTap = {
                        if (!flag.done) {
                            click?.let {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                it()
                            }
                        }
                    }
                )
            }
            .padding(padding),
        content = content
    )
}

// การ์ดที่กดค้างแล้วมีเมนู คัดลอก / แชร์
@Composable
fun ActionCard(
    title: String,
    text: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box(modifier) {
        GlowCard(
            Modifier.fillMaxWidth(),
            onClick = onClick,
            onLongClick = { menu = true },
            content = content
        )
        DropdownMenu(
            expanded = menu,
            onDismissRequest = { menu = false },
            modifier = Modifier.background(CardBg)
        ) {
            DropdownMenuItem(
                text = { Txt("📋  คัดลอก", 15) },
                onClick = { menu = false; copyText(ctx, title, text) }
            )
            DropdownMenuItem(
                text = { Txt("📤  แชร์", 15) },
                onClick = { menu = false; shareText(ctx, title, text) }
            )
        }
    }
}

// การ์ดเลื่อนขึ้น+จางเข้า ผ่าน graphicsLayer (ไม่ทำให้ layout เปลี่ยน จึงลื่น)
@Composable
fun Reveal(index: Int, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 40L)
        a.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
    }
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = a.value
                translationY = (1f - a.value) * 32.dp.toPx()
            }
    ) { content() }
}

@Composable
fun Hero(emoji: String, title: String, subtitle: String) {
    val t = rememberInfiniteTransition(label = "hero")
    val shift by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Reverse),
        label = "shift"
    )
    val colors = remember { listOf(Accent, Accent2, Color(0xFF3A0010)) }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(topStart = 28.dp, bottomEnd = 28.dp))
            .drawBehind {
                val w = size.width
                drawRect(
                    Brush.linearGradient(
                        colors,
                        start = Offset(w * (shift - 0.5f), 0f),
                        end = Offset(w * (shift + 0.5f), size.height)
                    )
                )
            }
            .padding(22.dp)
    ) {
        Column {
            Txt(emoji, 34)
            Spacer(Modifier.height(8.dp))
            Txt(title, 24, bold = true)
            Spacer(Modifier.height(2.dp))
            Txt(subtitle, 14, Color.White.copy(alpha = 0.8f))
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Txt(text, 14, Accent, bold = true, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
fun KV(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Txt(k, 13, Dim, modifier = Modifier.weight(0.42f))
        Txt(v, 13, Color.White, bold = true, modifier = Modifier.weight(0.58f), align = TextAlign.End)
    }
}

@Composable
fun InfoCard(title: String, rows: Rows) {
    ActionCard(
        title,
        rows.joinToString("\n") { "${it.first}: ${it.second}" },
        modifier = Modifier.fillMaxWidth()
    ) {
        SectionTitle(title)
        rows.forEach { KV(it.first, it.second) }
    }
}

@Composable
fun NoteCard(title: String, text: String) {
    GlowCard(Modifier.fillMaxWidth()) {
        SectionTitle(title)
        Txt(text, 13, Dim)
    }
}

// แตะ = พับ/ขยาย, กดค้าง = คัดลอก/แชร์
@Composable
fun ExpandCard(title: String, rows: Rows) {
    var open by remember { mutableStateOf(false) }
    ActionCard(
        title,
        rows.joinToString("\n") { "${it.first}: ${it.second}" },
        modifier = Modifier.fillMaxWidth().animateContentSize(spring(stiffness = 300f)),
        onClick = { open = !open }
    ) {
        SectionTitle("$title  ${if (open) "▲" else "▼"}")
        if (open) rows.forEach { KV(it.first, it.second) }
        else Txt("แตะเพื่อดูรายการ", 13, Dim)
    }
}

@Composable
fun CoreBar(c: Core, curKhz: Long?) {
    val max = c.maxKhz ?: 3_000_000L
    val frac by animateFloatAsState(
        targetValue = if (curKhz == null) 0f else (curKhz.toFloat() / max).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "bar"
    )
    Column(Modifier.padding(vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Txt("CPU${c.id} · ${c.name}", 12, Dim, modifier = Modifier.weight(1f))
            Txt(
                if (curKhz == null) "—" else "${curKhz / 1000} / ${max / 1000} MHz",
                12, Color.White, bold = true
            )
        }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.White.copy(alpha = 0.07f))
                .drawBehind {
                    drawRect(
                        brush = Brush.horizontalGradient(listOf(Accent, Accent2), endX = size.width),
                        size = Size(size.width * frac, size.height)
                    )
                }
        )
    }
}

@Composable
fun RingGauge(
    fraction: Float, color: Color, big: String, small: String,
    size: Dp = 210.dp, bigSize: Int = 38
) {
    val frac by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(900), label = "ring")
    val col by animateColorAsState(color, tween(600), label = "ringColor")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = (size.value / 9.5f).dp.toPx()
            val topLeft = Offset(stroke / 2, stroke / 2)
            val arc = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = topLeft, size = arc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = col,
                startAngle = 135f, sweepAngle = 270f * frac, useCenter = false,
                topLeft = topLeft, size = arc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(big, bigSize, bold = true)
            Txt(small, 13, Dim)
        }
    }
}

// ───────── แถบเมนูลอยด้านล่าง ─────────
data class Tab(val icon: String, val label: String)

@Composable
fun FloatingNav(selected: Int, tabs: List<Tab>, onSelect: (Int) -> Unit) {
    val shape = CutCornerShape(topStart = 22.dp, bottomEnd = 22.dp)
    Row(
        Modifier
            .clip(shape)
            .background(Color(0xF01A1B20))
            .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEachIndexed { i, t -> NavItem(t, i == selected) { onSelect(i) } }
    }
}

@Composable
fun NavItem(tab: Tab, selected: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val bg by animateColorAsState(
        if (selected) Accent.copy(alpha = 0.28f) else Color.Transparent, label = "navBg"
    )
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier
            .animateContentSize(tween(180))
            .clip(CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
            .background(bg)
            .clickable(interactionSource = src, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Txt(tab.icon, 20)
        if (selected) {
            Spacer(Modifier.width(6.dp))
            Text(
                tab.label, color = Accent, fontSize = 13.sp,
                fontWeight = FontWeight.Bold, maxLines = 1
            )
        }
    }
}
