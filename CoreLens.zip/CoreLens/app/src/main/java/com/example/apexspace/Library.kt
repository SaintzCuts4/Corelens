package com.example.apexspace

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(val pkg: String, val label: String, val icon: ImageBitmap, val isGame: Boolean)

object Library {
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (ri in list) {
            val ai = ri.activityInfo?.applicationInfo ?: continue
            val pkg = ai.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            @Suppress("DEPRECATION")
            val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            val bmp = try {
                ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                continue
            }
            out.add(AppEntry(pkg, ri.loadLabel(pm).toString(), bmp, isGame))
        }
        return out.sortedBy { it.label.lowercase() }
    }
}

object OverlayCtl {
    // เริ่ม overlay (ขอสิทธิ์ "แสดงทับแอปอื่น" ถ้ายังไม่ได้เปิด)
    fun ensureStarted(ctx: Context): Boolean {
        if (!Settings.canDrawOverlays(ctx)) {
            Toast.makeText(ctx, "เปิดสิทธิ์ \"แสดงทับแอปอื่น\" แล้วกลับมากดอีกครั้ง", Toast.LENGTH_LONG).show()
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
            )
            return false
        }
        if (!OverlayState.running) OverlayService.start(ctx)
        return true
    }

    fun toggle(ctx: Context) {
        if (OverlayState.running) OverlayService.stop(ctx) else ensureStarted(ctx)
    }

    fun launchGame(ctx: Context, pkg: String) {
        if (!ensureStarted(ctx)) return
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
    }
}
