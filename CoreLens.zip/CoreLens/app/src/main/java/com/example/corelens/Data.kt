package com.example.corelens

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.Display
import java.io.File
import java.util.Locale

typealias Rows = List<Pair<String, String>>

object Sys {
    fun read(path: String): String? =
        try { File(path).readText().trim().ifEmpty { null } } catch (e: Exception) { null }

    fun readLong(path: String): Long? = read(path)?.toLongOrNull()
}

object Fmt {
    fun f1(x: Float): String = String.format(Locale.US, "%.1f", x)

    fun bytes(b: Long): String {
        val gb = b / 1024.0 / 1024.0 / 1024.0
        return if (gb >= 1) String.format(Locale.US, "%.2f GB", gb)
        else String.format(Locale.US, "%.0f MB", b / 1024.0 / 1024.0)
    }
}

// ───────────────────────── ตัวเครื่อง ─────────────────────────
object Info {
    fun marketName(ctx: Context): String {
        val n = try { Settings.Global.getString(ctx.contentResolver, "device_name") } catch (e: Exception) { null }
        return n?.takeIf { it.isNotBlank() }
            ?: "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    }

    fun deviceGroups(ctx: Context): List<Pair<String, Rows>> {
        val dm = ctx.resources.displayMetrics
        val disp = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
        val hz = disp?.refreshRate?.let { String.format(Locale.US, "%.0f Hz", it) } ?: "-"
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        val usedPct = if (mi.totalMem > 0) (mi.totalMem - mi.availMem) * 100 / mi.totalMem else 0L

        return listOf(
            "ตัวเครื่อง" to listOf(
                "ยี่ห้อ" to Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
                "รุ่น" to Build.MODEL,
                "ชื่อรหัส" to Build.DEVICE,
                "ผลิตภัณฑ์" to Build.PRODUCT,
                "บอร์ด" to Build.BOARD,
                "ฮาร์ดแวร์" to Build.HARDWARE
            ),
            "ระบบ" to listOf(
                "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                "แพตช์ความปลอดภัย" to (Build.VERSION.SECURITY_PATCH ?: "-"),
                "Build" to Build.DISPLAY,
                "Kernel" to (System.getProperty("os.version") ?: "-")
            ),
            "หน้าจอ" to listOf(
                "ความละเอียด" to "${dm.widthPixels} × ${dm.heightPixels}",
                "ความหนาแน่น" to "${dm.densityDpi} dpi (×${String.format(Locale.US, "%.2f", dm.density)})",
                "รีเฟรชเรต" to hz
            ),
            "หน่วยความจำ" to listOf(
                "RAM ทั้งหมด" to Fmt.bytes(mi.totalMem),
                "RAM ว่าง" to Fmt.bytes(mi.availMem),
                "RAM ที่ใช้" to "$usedPct%",
                "พื้นที่เก็บข้อมูล" to Fmt.bytes(total),
                "พื้นที่ว่าง" to Fmt.bytes(free)
            )
        )
    }

    fun sensors(ctx: Context): Rows {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        return sm.getSensorList(Sensor.TYPE_ALL).map { it.name to it.vendor }
    }
}

// ───────────────────────── CPU ─────────────────────────
data class Core(val id: Int, val name: String, val maxKhz: Long?, val minKhz: Long?)

object Cpu {
    private val arm = mapOf(
        0xd03 to "Cortex-A53", 0xd04 to "Cortex-A35", 0xd05 to "Cortex-A55", 0xd07 to "Cortex-A57",
        0xd08 to "Cortex-A72", 0xd09 to "Cortex-A73", 0xd0a to "Cortex-A75", 0xd0b to "Cortex-A76",
        0xd0d to "Cortex-A77", 0xd41 to "Cortex-A78", 0xd44 to "Cortex-X1", 0xd46 to "Cortex-A510",
        0xd47 to "Cortex-A710", 0xd48 to "Cortex-X2", 0xd4d to "Cortex-A715", 0xd4e to "Cortex-X3",
        0xd80 to "Cortex-A520", 0xd81 to "Cortex-A720", 0xd82 to "Cortex-X4", 0xd85 to "Cortex-X925",
        0xd87 to "Cortex-A725"
    )
    private val kryo = mapOf(
        0x800 to "Kryo 2xx Gold", 0x801 to "Kryo 2xx Silver", 0x803 to "Kryo 3xx Silver",
        0x804 to "Kryo 4xx Gold", 0x805 to "Kryo 4xx Silver"
    )

    private fun coreName(impl: Int?, part: Int?): String {
        if (part == null) return "ไม่ทราบรุ่น"
        if (impl == 0x41 || impl == null) arm[part]?.let { return it }
        if (impl == 0x51) kryo[part]?.let { return it }
        val maker = when (impl) {
            0x41 -> "ARM"; 0x51 -> "Qualcomm"; 0x53 -> "Samsung"
            0x48 -> "HiSilicon"; 0x4e -> "NVIDIA"; 0x61 -> "Apple"
            else -> "ID " + (impl?.toString(16) ?: "?")
        }
        return "$maker 0x${part.toString(16)}"
    }

    // อ่านจาก /proc/cpuinfo : core id -> (implementer, part)
    private fun parseCpuInfo(): Map<Int, Pair<Int?, Int?>> {
        val txt = Sys.read("/proc/cpuinfo") ?: return emptyMap()
        val out = mutableMapOf<Int, Pair<Int?, Int?>>()
        var id = -1
        var impl: Int? = null
        var part: Int? = null
        fun flush() {
            if (id >= 0) out[id] = Pair(impl, part)
            id = -1; impl = null; part = null
        }
        for (line in txt.lines()) {
            val idx = line.indexOf(':')
            if (idx < 0) { if (line.isBlank()) flush(); continue }
            val k = line.substring(0, idx).trim()
            val v = line.substring(idx + 1).trim()
            when (k) {
                "processor" -> { flush(); id = v.toIntOrNull() ?: -1 }
                "CPU implementer" -> impl = v.removePrefix("0x").toIntOrNull(16)
                "CPU part" -> part = v.removePrefix("0x").toIntOrNull(16)
            }
        }
        flush()
        return out
    }

    fun cores(): List<Core> {
        val dirs = File("/sys/devices/system/cpu").list()?.count { Regex("cpu\\d+").matches(it) } ?: 0
        val n = maxOf(dirs, Runtime.getRuntime().availableProcessors())
        val info = parseCpuInfo()
        return (0 until n).map { i ->
            val p = info[i]
            Core(
                id = i,
                name = coreName(p?.first, p?.second),
                maxKhz = Sys.readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq"),
                minKhz = Sys.readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_min_freq")
            )
        }
    }

    fun curKhz(id: Int): Long? =
        Sys.readLong("/sys/devices/system/cpu/cpu$id/cpufreq/scaling_cur_freq")
            ?: Sys.readLong("/sys/devices/system/cpu/cpu$id/cpufreq/cpuinfo_cur_freq")

    fun governor(): String? = Sys.read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")

    fun soc(): String {
        if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != Build.UNKNOWN) {
            return "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim()
        }
        val hw = Sys.read("/proc/cpuinfo")?.lines()
            ?.firstOrNull { it.startsWith("Hardware") }?.substringAfter(':')?.trim()
        return hw?.takeIf { it.isNotBlank() } ?: Build.HARDWARE
    }
}

// ───────────────────────── GPU ─────────────────────────
data class GpuData(
    val renderer: String, val vendor: String, val version: String,
    val glsl: String, val maxTex: Int, val extCount: Int
)

object Gpu {
    fun query(): GpuData? {
        var dpy = EGL14.EGL_NO_DISPLAY
        var ectx = EGL14.EGL_NO_CONTEXT
        var surf = EGL14.EGL_NO_SURFACE
        return try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val ver = IntArray(2)
            if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) return null
            val attrs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val num = IntArray(1)
            EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, num, 0)
            val cfg = cfgs[0] ?: return null
            ectx = EGL14.eglCreateContext(
                dpy, cfg, EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
            surf = EGL14.eglCreatePbufferSurface(
                dpy, cfg, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
            )
            if (!EGL14.eglMakeCurrent(dpy, surf, surf, ectx)) return null
            val tex = IntArray(1)
            GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, tex, 0)
            GpuData(
                renderer = GLES20.glGetString(GLES20.GL_RENDERER) ?: "-",
                vendor = GLES20.glGetString(GLES20.GL_VENDOR) ?: "-",
                version = GLES20.glGetString(GLES20.GL_VERSION) ?: "-",
                glsl = GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION) ?: "-",
                maxTex = tex[0],
                extCount = GLES20.glGetString(GLES20.GL_EXTENSIONS)?.trim()?.split(" ")?.size ?: 0
            )
        } catch (e: Exception) {
            null
        } finally {
            try {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf)
                if (ectx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ectx)
                if (dpy != EGL14.EGL_NO_DISPLAY) EGL14.eglTerminate(dpy)
            } catch (e: Exception) { /* ignore */ }
        }
    }

    fun glEsSupported(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return am.deviceConfigurationInfo.glEsVersion ?: "-"
    }

    fun vulkan(ctx: Context): String {
        val f = ctx.packageManager.systemAvailableFeatures
            .firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }
        val v = f?.version ?: return "ไม่รองรับ"
        return "${v shr 22}.${(v shr 12) and 0x3ff}.${v and 0xfff}"
    }

    // ความถี่ GPU (Hz) ถ้าระบบยอมให้อ่าน
    fun freqHz(): Long? {
        for (p in listOf("/sys/class/kgsl/kgsl-3d0/gpuclk", "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq")) {
            Sys.readLong(p)?.let { return it }
        }
        File("/sys/class/devfreq").listFiles()?.forEach { d ->
            val n = d.name.lowercase()
            if ("mali" in n || "gpu" in n || "kgsl" in n) {
                Sys.readLong("${d.path}/cur_freq")?.let { return it }
            }
        }
        return null
    }
}

// ───────────────────────── อุณหภูมิ / แบตเตอรี่ ─────────────────────────
data class BatteryData(
    val level: Int, val tempC: Float, val voltageMv: Int, val status: String,
    val health: String, val plugged: String, val tech: String, val currentMa: Int?
)

data class ThermalSnap(
    val battery: BatteryData,
    val zones: List<Pair<String, Float>>,
    val status: String,
    val headroom: Float?
)

object Power {
    fun battery(ctx: Context): BatteryData {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val scale = (i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        val level = (i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / scale
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val volt = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val status = when (i?.getIntExtra(BatteryManager.EXTRA_STATUS, 0)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "กำลังชาร์จ"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "กำลังใช้แบต"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "ไม่ได้ชาร์จ"
            BatteryManager.BATTERY_STATUS_FULL -> "เต็ม"
            else -> "-"
        }
        val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "ดี"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "ร้อนเกิน"
            BatteryManager.BATTERY_HEALTH_DEAD -> "เสื่อม"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "แรงดันเกิน"
            BatteryManager.BATTERY_HEALTH_COLD -> "เย็นเกิน"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "ผิดปกติ"
            else -> "-"
        }
        val plugged = when (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "ที่ชาร์จ (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "ไร้สาย"
            else -> "ไม่ได้เสียบ"
        }
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val ua = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val ma = if (ua == Int.MIN_VALUE || ua == 0) null else ua / 1000
        return BatteryData(level, temp, volt, status, health, plugged, i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "-", ma)
    }

    private fun thermalStatus(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 29) return "ไม่รองรับ (ต้อง Android 10+)"
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            0 -> "ปกติ"
            1 -> "อุ่นเล็กน้อย"
            2 -> "ร้อนปานกลาง"
            3 -> "ร้อนมาก (เริ่มลดสมรรถนะ)"
            4 -> "วิกฤต"
            5 -> "ฉุกเฉิน"
            6 -> "ใกล้ปิดเครื่อง"
            else -> "-"
        }
    }

    private fun headroom(ctx: Context): Float? {
        if (Build.VERSION.SDK_INT < 30) return null
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val h = pm.getThermalHeadroom(10)
        return if (h.isNaN()) null else h
    }

    // เซนเซอร์ความร้อนของระบบ (CPU/GPU/skin ...) อ่านได้เฉพาะเครื่องที่ไม่บล็อก
    private fun zones(): List<Pair<String, Float>> {
        val dirs = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") } ?: return emptyList()
        return dirs.mapNotNull { d ->
            val raw = Sys.readLong("${d.path}/temp") ?: return@mapNotNull null
            val c = if (raw > 1000) raw / 1000f else raw.toFloat()
            if (c <= 0f || c > 130f) null else (Sys.read("${d.path}/type") ?: d.name) to c
        }
    }

    fun snapshot(ctx: Context): ThermalSnap =
        ThermalSnap(battery(ctx), zones(), thermalStatus(ctx), headroom(ctx))
}
