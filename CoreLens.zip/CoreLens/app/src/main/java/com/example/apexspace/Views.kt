package com.example.apexspace

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.max

// พื้นหลังทรงเหลี่ยมตัดมุม (มุมบนซ้าย + ล่างขวา) สไตล์เกมมิ่ง
class AngularBg(
    private val fill: Int,
    private val stroke: Int,
    private val cut: Float,
    private val strokeW: Float
) : Drawable() {
    private val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fill }
    private val ps = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = stroke; strokeWidth = strokeW
    }
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val i = strokeW / 2f
        val l = bounds.left + i
        val t = bounds.top + i
        val r = bounds.right - i
        val b = bounds.bottom - i
        path.reset()
        path.moveTo(l + cut, t)
        path.lineTo(r, t)
        path.lineTo(r, b - cut)
        path.lineTo(r - cut, b)
        path.lineTo(l, b)
        path.lineTo(l, t + cut)
        path.close()
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, pf)
        if (strokeW > 0f) canvas.drawPath(path, ps)
    }

    override fun setAlpha(alpha: Int) {
        pf.alpha = alpha
        ps.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        pf.colorFilter = colorFilter
        ps.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// เป้าเล็ง (Crosshair) วาดกลางจอ + ออฟเซ็ต
class CrosshairView(ctx: Context) : View(ctx) {
    var cfg: Cross = Cross()
        set(v) {
            field = v
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val d = ctx.resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f + cfg.offX * d
        val cy = height / 2f + cfg.offY * d
        val a = (cfg.opacity.coerceIn(10, 100) * 255) / 100
        if (cfg.outline) render(canvas, cx, cy, Color.BLACK, (cfg.thickness + 2) * d, a, true)
        render(canvas, cx, cy, cfg.color, cfg.thickness * d, a, false)
    }

    private fun plus(c: Canvas, cx: Float, cy: Float, len: Float, gap: Float, e: Float, top: Boolean, bottom: Boolean) {
        c.drawLine(cx - gap - len - e, cy, cx - gap + e, cy, p)
        c.drawLine(cx + gap - e, cy, cx + gap + len + e, cy, p)
        if (top) c.drawLine(cx, cy - gap - len - e, cx, cy - gap + e, p)
        if (bottom) c.drawLine(cx, cy + gap - e, cx, cy + gap + len + e, p)
    }

    private fun dot(c: Canvas, cx: Float, cy: Float, w: Float, e: Float) {
        p.style = Paint.Style.FILL
        c.drawCircle(cx, cy, max(w * 1.4f, 2f * d) + e, p)
        p.style = Paint.Style.STROKE
    }

    private fun render(c: Canvas, cx: Float, cy: Float, color: Int, w: Float, alpha: Int, outline: Boolean) {
        val len = cfg.size * d
        val gap = cfg.gap * d
        val e = if (outline) d else 0f
        p.reset()
        p.isAntiAlias = true
        p.color = color
        p.alpha = alpha
        p.strokeWidth = w
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeJoin = Paint.Join.MITER
        when (cfg.style) {
            1 -> dot(c, cx, cy, w, e)
            2 -> c.drawCircle(cx, cy, len / 2f + gap, p)
            3 -> {
                c.drawCircle(cx, cy, len / 2f + gap, p)
                dot(c, cx, cy, w, e)
            }
            4 -> {
                plus(c, cx, cy, len, gap, e, true, true)
                dot(c, cx, cy, w, e)
            }
            5 -> plus(c, cx, cy, len, gap, e, false, true)
            6 -> {
                val dd = gap * 0.707f
                val l2 = len * 0.707f
                c.drawLine(cx - dd + e, cy - dd + e, cx - dd - l2 - e, cy - dd - l2 - e, p)
                c.drawLine(cx + dd - e, cy - dd + e, cx + dd + l2 + e, cy - dd - l2 - e, p)
                c.drawLine(cx - dd + e, cy + dd - e, cx - dd - l2 - e, cy + dd + l2 + e, p)
                c.drawLine(cx + dd - e, cy + dd - e, cx + dd + l2 + e, cy + dd + l2 + e, p)
            }
            7 -> {
                path.reset()
                path.moveTo(cx - len * 0.7f, cy + len * 0.5f)
                path.lineTo(cx, cy - len * 0.2f)
                path.lineTo(cx + len * 0.7f, cy + len * 0.5f)
                c.drawPath(path, p)
            }
            else -> plus(c, cx, cy, len, gap, e, true, true)
        }
    }
}
