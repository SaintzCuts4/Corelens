package com.example.apexspace

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

// สถานะ overlay (ให้หน้าแอปอ่านได้แบบ real-time)
object OverlayState {
    var running by mutableStateOf(false)
}

val CROSS_NAMES = listOf("CROSS", "DOT", "RING", "RING+DOT", "CROSS+DOT", "T-SHAPE", "X", "CHEVRON")

val CROSS_COLORS = listOf(
    0xFFFF2442.toInt(), // แดง
    0xFF00FF66.toInt(), // เขียว
    0xFF00E5FF.toInt(), // ฟ้า
    0xFFFFEB3B.toInt(), // เหลือง
    0xFFFFFFFF.toInt(), // ขาว
    0xFFFF00E5.toInt(), // ชมพู
    0xFFFF7A18.toInt()  // ส้ม
)

data class Cross(
    val on: Boolean = true,
    val style: Int = 0,
    val color: Int = 0xFF00FF66.toInt(),
    val size: Int = 12,
    val thickness: Int = 2,
    val gap: Int = 4,
    val opacity: Int = 100,
    val offX: Int = 0,
    val offY: Int = 0,
    val outline: Boolean = true
)

data class Hud(
    val on: Boolean = true,
    val battery: Boolean = true,
    val temp: Boolean = true,
    val power: Boolean = true,
    val ram: Boolean = true,
    val cpu: Boolean = true,
    val ping: Boolean = true,
    val hz: Boolean = true,
    val clock: Boolean = false,
    val pos: Int = 0,               // 0 บนซ้าย 1 บนกลาง 2 บนขวา 3 ล่างซ้าย 4 ล่างกลาง 5 ล่างขวา
    val vertical: Boolean = false,
    val opacity: Int = 80,
    val textSize: Int = 12,
    val intervalSec: Int = 1,
    val pingTarget: Int = 0,
    val handle: Boolean = true,     // แถบขอบจอสำหรับเปิดแผงควบคุมระหว่างเล่นเกม
    val handleRight: Boolean = false
)

object Store {
    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("apex", Context.MODE_PRIVATE)

    fun loadCross(ctx: Context): Cross {
        val p = prefs(ctx)
        val d = Cross()
        return Cross(
            on = p.getBoolean("c_on", d.on),
            style = p.getInt("c_style", d.style),
            color = p.getInt("c_color", d.color),
            size = p.getInt("c_size", d.size),
            thickness = p.getInt("c_thick", d.thickness),
            gap = p.getInt("c_gap", d.gap),
            opacity = p.getInt("c_op", d.opacity),
            offX = p.getInt("c_ox", d.offX),
            offY = p.getInt("c_oy", d.offY),
            outline = p.getBoolean("c_outline", d.outline)
        )
    }

    fun saveCross(ctx: Context, c: Cross) {
        prefs(ctx).edit()
            .putBoolean("c_on", c.on)
            .putInt("c_style", c.style)
            .putInt("c_color", c.color)
            .putInt("c_size", c.size)
            .putInt("c_thick", c.thickness)
            .putInt("c_gap", c.gap)
            .putInt("c_op", c.opacity)
            .putInt("c_ox", c.offX)
            .putInt("c_oy", c.offY)
            .putBoolean("c_outline", c.outline)
            .apply()
    }

    fun loadHud(ctx: Context): Hud {
        val p = prefs(ctx)
        val d = Hud()
        return Hud(
            on = p.getBoolean("h_on", d.on),
            battery = p.getBoolean("h_bat", d.battery),
            temp = p.getBoolean("h_temp", d.temp),
            power = p.getBoolean("h_pwr", d.power),
            ram = p.getBoolean("h_ram", d.ram),
            cpu = p.getBoolean("h_cpu", d.cpu),
            ping = p.getBoolean("h_ping", d.ping),
            hz = p.getBoolean("h_hz", d.hz),
            clock = p.getBoolean("h_clock", d.clock),
            pos = p.getInt("h_pos", d.pos),
            vertical = p.getBoolean("h_vert", d.vertical),
            opacity = p.getInt("h_op", d.opacity),
            textSize = p.getInt("h_size", d.textSize),
            intervalSec = p.getInt("h_int", d.intervalSec),
            pingTarget = p.getInt("h_pt", d.pingTarget),
            handle = p.getBoolean("h_handle", d.handle),
            handleRight = p.getBoolean("h_right", d.handleRight)
        )
    }

    fun saveHud(ctx: Context, h: Hud) {
        prefs(ctx).edit()
            .putBoolean("h_on", h.on)
            .putBoolean("h_bat", h.battery)
            .putBoolean("h_temp", h.temp)
            .putBoolean("h_pwr", h.power)
            .putBoolean("h_ram", h.ram)
            .putBoolean("h_cpu", h.cpu)
            .putBoolean("h_ping", h.ping)
            .putBoolean("h_hz", h.hz)
            .putBoolean("h_clock", h.clock)
            .putInt("h_pos", h.pos)
            .putBoolean("h_vert", h.vertical)
            .putInt("h_op", h.opacity)
            .putInt("h_size", h.textSize)
            .putInt("h_int", h.intervalSec)
            .putInt("h_pt", h.pingTarget)
            .putBoolean("h_handle", h.handle)
            .putBoolean("h_right", h.handleRight)
            .apply()
    }

    fun library(ctx: Context): Set<String>? = prefs(ctx).getStringSet("lib", null)?.toSet()

    fun saveLibrary(ctx: Context, s: Set<String>) {
        prefs(ctx).edit().putStringSet("lib", HashSet(s)).apply()
    }

    fun handleY(ctx: Context): Int = prefs(ctx).getInt("handle_y", -1)

    fun saveHandleY(ctx: Context, y: Int) {
        prefs(ctx).edit().putInt("handle_y", y).apply()
    }
}
