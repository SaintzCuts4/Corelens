package com.example.apexspace

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Txt(title, 14, bold = true)
            if (sub.isNotEmpty()) Txt(sub, 11, Dim)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Accent,
                checkedBorderColor = Accent,
                uncheckedThumbColor = Dim,
                uncheckedTrackColor = Color(0xFF23252B),
                uncheckedBorderColor = Color(0xFF3A3D45)
            )
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = remember { CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp) }
    val bg by animateColorAsState(
        if (selected) Accent.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.05f),
        tween(150), label = "chip"
    )
    val haptic = LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    Box(
        modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, if (selected) Accent else Color.White.copy(alpha = 0.12f), shape)
            .clickable(interactionSource = src, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Txt(text, 12, if (selected) Color.White else Dim, bold = selected)
    }
}

@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEachIndexed { i, label ->
            Chip(label, i == selected, Modifier.weight(1f)) { onSelect(i) }
        }
    }
}

@Composable
fun ChipScroll(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEachIndexed { i, label -> Chip(label, i == selected) { onSelect(i) } }
    }
}

@Composable
fun ColorDot(c: Int, selected: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color(c))
            .border(
                if (selected) 3.dp else 1.dp,
                if (selected) Color.White else Color.White.copy(alpha = 0.25f),
                CircleShape
            )
            .clickable(interactionSource = src, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
    )
}

@Composable
fun LabeledSlider(
    label: String, value: Int, min: Int, max: Int, suffix: String = "",
    onChange: (Int) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            Txt(label, 13, Dim, modifier = Modifier.weight(1f))
            Txt("$value$suffix", 13, bold = true)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = Color(0xFF2A2C33)
            )
        )
    }
}

@Composable
fun StatBar(label: String, value: String, frac: Float) {
    val f by animateFloatAsState(frac.coerceIn(0f, 1f), tween(450), label = "statbar")
    Column(Modifier.padding(vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Txt(label, 12, Dim, modifier = Modifier.weight(1f))
            Txt(value, 12, Color.White, bold = true)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .background(Color.White.copy(alpha = 0.07f))
                .drawBehind {
                    drawRect(
                        brush = Brush.horizontalGradient(listOf(Accent, Accent2), endX = size.width),
                        size = Size(size.width * f, size.height)
                    )
                }
        )
    }
}

// ปุ่มใหญ่ START / STOP overlay
@Composable
fun StartButton(running: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseV"
    )
    val shape = remember { CutCornerShape(topStart = 24.dp, bottomEnd = 24.dp) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "startScale"
    )
    Box(
        Modifier
            .fillMaxWidth()
            .height(76.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape)
            .drawBehind {
                if (running) {
                    drawRect(Color(0xFF16090B))
                    drawRect(Accent.copy(alpha = 0.08f + 0.20f * pulse))
                } else {
                    drawRect(Brush.horizontalGradient(listOf(Accent, Accent2)))
                }
            }
            .border(1.5.dp, if (running) Accent else Color.Transparent, shape)
            .clickable(interactionSource = src, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(if (running) "■   STOP OVERLAY" else "▶   START OVERLAY", 20, bold = true)
            Txt(if (running) "OVERLAY ACTIVE" else "TAP TO ENTER GAME MODE", 11, Color.White.copy(alpha = 0.75f))
        }
    }
}
