package com.example.apexspace

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun ApexApp() {
    val ctx = LocalContext.current
    var splash by remember { mutableStateOf(true) }
    var showMain by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(showMain) {
        if (showMain && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val tabs = remember {
        listOf(Tab("🎮", "GAMES"), Tab("🎯", "AIM"), Tab("📟", "HUD"), Tab("📊", "INFO"))
    }
    Box(Modifier.fillMaxSize().background(Bg)) {
        if (showMain) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(90)) },
                label = "tabs"
            ) { t ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .statusBarsPadding()
                        .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (t) {
                        0 -> HomeScreen()
                        1 -> CrosshairScreen()
                        2 -> HudScreen()
                        else -> InfoScreen()
                    }
                }
            }
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)
            ) { FloatingNav(tab, tabs) { tab = it } }
        }
        if (splash) Splash(onReveal = { showMain = true }, onDone = { splash = false })
    }
}

// ───────────────────────── GAMES ─────────────────────────
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val running = OverlayState.running
    var cross by remember { mutableStateOf(Store.loadCross(ctx)) }
    var hud by remember { mutableStateOf(Store.loadHud(ctx)) }
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var lib by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loaded by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val list = withContext(Dispatchers.Default) { Library.load(ctx) }
        val saved = Store.library(ctx)
            ?: list.filter { it.isGame }.map { it.pkg }.toSet().also { Store.saveLibrary(ctx, it) }
        apps = list
        lib = saved
        loaded = true
    }

    Reveal(0) { Hero("🎮", "APEX SPACE", "Game overlay • Crosshair • Live info") }
    Reveal(1) { StartButton(running) { OverlayCtl.toggle(ctx) } }
    Reveal(2) {
        GlowCard(Modifier.fillMaxWidth()) {
            SectionTitle("OVERLAY MODULES")
            SwitchRow("Crosshair", "เป้าเล็งกลางจอ", cross.on) {
                cross = cross.copy(on = it)
                Store.saveCross(ctx, cross)
            }
            SwitchRow("HUD Info", "แถบข้อมูลบนจอเกม", hud.on) {
                hud = hud.copy(on = it)
                Store.saveHud(ctx, hud)
            }
            SwitchRow("Edge Panel", "แถบขอบจอ แตะเพื่อเปิดแผงควบคุมในเกม", hud.handle) {
                hud = hud.copy(handle = it)
                Store.saveHud(ctx, hud)
            }
        }
    }
    Reveal(3) {
        Column {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt("GAME LIBRARY", 14, Accent, bold = true, modifier = Modifier.weight(1f))
                Chip("EDIT", false) { picker = true }
            }
            Spacer(Modifier.height(10.dp))
            val shown = apps.filter { it.pkg in lib }
            if (loaded && shown.isEmpty()) {
                Txt("ยังไม่มีเกมในรายการ กด EDIT เพื่อเลือกแอปที่ต้องการ", 13, Dim)
            }
            shown.chunked(3).forEach { rowApps ->
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowApps.forEach { a ->
                        GameTile(a, Modifier.weight(1f)) { OverlayCtl.launchGame(ctx, a.pkg) }
                    }
                    repeat(3 - rowApps.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Txt("แตะเกม = เปิดเกมพร้อม overlay อัตโนมัติ", 11, Dim)
        }
    }
    if (picker) {
        LibraryPicker(
            apps = apps,
            selected = lib,
            onToggle = { pkg ->
                val n = if (pkg in lib) lib - pkg else lib + pkg
                lib = n
                Store.saveLibrary(ctx, n)
            },
            onClose = { picker = false }
        )
    }
}

@Composable
fun GameTile(a: AppEntry, modifier: Modifier, onClick: () -> Unit) {
    GlowCard(modifier, onClick = onClick, padding = 10.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(bitmap = a.icon, contentDescription = null, modifier = Modifier.size(52.dp))
            Spacer(Modifier.height(6.dp))
            Text(
                a.label,
                color = Color.White,
                fontSize = 11.sp,
                maxLines = 2,
                minLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun LibraryPicker(
    apps: List<AppEntry>,
    selected: Set<String>,
    onToggle: (String) -> Unit,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 540.dp)
                .clip(CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp))
                .background(CardBg)
                .padding(14.dp)
        ) {
            Txt("เลือกแอปที่จะอยู่ใน Game Space", 15, bold = true)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(apps, key = { it.pkg }) { a ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onToggle(a.pkg) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(bitmap = a.icon, contentDescription = null, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.size(10.dp))
                        Txt(a.label, 14, modifier = Modifier.weight(1f))
                        Checkbox(
                            checked = a.pkg in selected,
                            onCheckedChange = { onToggle(a.pkg) },
                            colors = CheckboxDefaults.colors(checkedColor = Accent)
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Chip("DONE", true, Modifier.fillMaxWidth()) { onClose() }
        }
    }
}

// ───────────────────────── AIM (Crosshair) ─────────────────────────
@Composable
fun CrosshairScreen() {
    val ctx = LocalContext.current
    var c by remember { mutableStateOf(Store.loadCross(ctx)) }
    fun upd(n: Cross) {
        c = n
        Store.saveCross(ctx, n)
    }

    Reveal(0) {
        GlowCard(Modifier.fillMaxWidth(), padding = 0.dp) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .background(Color(0xFF0B0C0F))
                    .drawBehind {
                        val step = 24.dp.toPx()
                        var x = 0f
                        while (x < size.width) {
                            drawLine(Color.White.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, size.height), 1f)
                            x += step
                        }
                        var y = 0f
                        while (y < size.height) {
                            drawLine(Color.White.copy(alpha = 0.05f), Offset(0f, y), Offset(size.width, y), 1f)
                            y += step
                        }
                    }
            ) {
                AndroidView(
                    factory = { context -> CrosshairView(context).apply { cfg = c } },
                    update = { it.cfg = c },
                    modifier = Modifier.fillMaxSize()
                )
                Txt("PREVIEW", 11, Dim, modifier = Modifier.align(Alignment.TopStart).padding(10.dp))
            }
        }
    }
    Reveal(1) {
        GlowCard(Modifier.fillMaxWidth()) {
            SwitchRow("Crosshair overlay", "แสดงเป้าเล็งทับเกม", c.on) { upd(c.copy(on = it)) }
            SectionTitle("STYLE")
            ChipScroll(CROSS_NAMES, c.style) { upd(c.copy(style = it)) }
            Spacer(Modifier.height(12.dp))
            SectionTitle("COLOR")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CROSS_COLORS.forEach { col -> ColorDot(col, c.color == col) { upd(c.copy(color = col)) } }
            }
        }
    }
    Reveal(2) {
        GlowCard(Modifier.fillMaxWidth()) {
            SectionTitle("ADJUST")
            LabeledSlider("SIZE", c.size, 4, 60, "dp") { upd(c.copy(size = it)) }
            LabeledSlider("THICKNESS", c.thickness, 1, 8, "dp") { upd(c.copy(thickness = it)) }
            LabeledSlider("GAP", c.gap, 0, 30, "dp") { upd(c.copy(gap = it)) }
            LabeledSlider("OPACITY", c.opacity, 10, 100, "%") { upd(c.copy(opacity = it)) }
            LabeledSlider("OFFSET X", c.offX, -150, 150, "") { upd(c.copy(offX = it)) }
            LabeledSlider("OFFSET Y", c.offY, -150, 150, "") { upd(c.copy(offY = it)) }
            SwitchRow("Outline", "ขอบดำให้เห็นชัดบนพื้นหลังสว่าง", c.outline) { upd(c.copy(outline = it)) }
            Spacer(Modifier.height(6.dp))
            Chip("RESET", false, Modifier.fillMaxWidth()) { upd(Cross(on = c.on)) }
        }
    }
}

// ───────────────────────── HUD ─────────────────────────
@Composable
fun HudScreen() {
    val ctx = LocalContext.current
    var h by remember { mutableStateOf(Store.loadHud(ctx)) }
    fun upd(n: Hud) {
        h = n
        Store.saveHud(ctx, n)
    }
    var stats by remember { mutableStateOf<LiveStats?>(null) }
    var ping by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(Unit) {
        val ids = withContext(Dispatchers.IO) { Cpu.cores().map { it.id } }
        while (true) {
            stats = withContext(Dispatchers.IO) { Stats.read(ctx, ids) }
            delay(1500)
        }
    }
    LaunchedEffect(h.pingTarget) {
        while (true) {
            ping = withContext(Dispatchers.IO) { Ping.measure(h.pingTarget) }
            delay(3000)
        }
    }

    Reveal(0) {
        GlowCard(Modifier.fillMaxWidth()) {
            SectionTitle("PREVIEW")
            val items = hudItems(h, stats, ping)
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
                    .background(Color.Black.copy(alpha = h.opacity / 100f))
                    .padding(12.dp)
            ) {
                if (items.isEmpty()) {
                    Txt("กำลังอ่านค่า…", 12, Dim)
                } else {
                    Text(
                        text = buildAnnotatedString {
                            items.forEachIndexed { i, kv ->
                                if (i > 0) append(if (h.vertical) "\n" else "   ")
                                withStyle(SpanStyle(color = Accent, fontWeight = FontWeight.Bold)) {
                                    append(kv.first + " ")
                                }
                                append(kv.second)
                            }
                        },
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontSize = h.textSize.sp
                    )
                }
            }
        }
    }
    Reveal(1) {
        GlowCard(Modifier.fillMaxWidth()) {
            SwitchRow("HUD Info", "แสดงแถบข้อมูลทับเกม", h.on) { upd(h.copy(on = it)) }
            SectionTitle("METRICS")
            SwitchRow("Battery", "แบตเตอรี่ %", h.battery) { upd(h.copy(battery = it)) }
            SwitchRow("Temp", "อุณหภูมิแบต", h.temp) { upd(h.copy(temp = it)) }
            SwitchRow("Power", "กำลังไฟขณะนี้ (W)", h.power) { upd(h.copy(power = it)) }
            SwitchRow("RAM", "การใช้ RAM", h.ram) { upd(h.copy(ram = it)) }
            SwitchRow("CPU", "ความเร็วสูงสุดของคอร์ (MHz)", h.cpu) { upd(h.copy(cpu = it)) }
            SwitchRow("Ping", "ความหน่วงเครือข่าย", h.ping) { upd(h.copy(ping = it)) }
            SwitchRow("Refresh", "รีเฟรชเรตจอ (Hz)", h.hz) { upd(h.copy(hz = it)) }
            SwitchRow("Clock", "นาฬิกา", h.clock) { upd(h.copy(clock = it)) }
        }
    }
    Reveal(2) {
        GlowCard(Modifier.fillMaxWidth()) {
            SectionTitle("POSITION")
            ChipRow(listOf("TOP-L", "TOP", "TOP-R"), if (h.pos < 3) h.pos else -1) { upd(h.copy(pos = it)) }
            Spacer(Modifier.height(6.dp))
            ChipRow(listOf("BTM-L", "BTM", "BTM-R"), if (h.pos >= 3) h.pos - 3 else -1) { upd(h.copy(pos = it + 3)) }
            Spacer(Modifier.height(12.dp))
            SectionTitle("LAYOUT")
            ChipRow(listOf("HORIZONTAL", "VERTICAL"), if (h.vertical) 1 else 0) { upd(h.copy(vertical = it == 1)) }
            Spacer(Modifier.height(8.dp))
            LabeledSlider("OPACITY", h.opacity, 20, 100, "%") { upd(h.copy(opacity = it)) }
            LabeledSlider("TEXT SIZE", h.textSize, 9, 22, "sp") { upd(h.copy(textSize = it)) }
            SectionTitle("UPDATE")
            val ints = listOf(1, 2, 5)
            ChipRow(listOf("1 s", "2 s", "5 s"), ints.indexOf(h.intervalSec)) { upd(h.copy(intervalSec = ints[it])) }
            Spacer(Modifier.height(12.dp))
            SectionTitle("PING TARGET")
            ChipScroll(PING_NAMES, h.pingTarget) { upd(h.copy(pingTarget = it)) }
        }
    }
    Reveal(3) {
        GlowCard(Modifier.fillMaxWidth()) {
            SectionTitle("EDGE PANEL")
            SwitchRow("Edge Panel", "แถบบาง ๆ ที่ขอบจอ แตะแล้วเปิดแผงควบคุมระหว่างเล่นเกม", h.handle) {
                upd(h.copy(handle = it))
            }
            ChipRow(listOf("LEFT", "RIGHT"), if (h.handleRight) 1 else 0) { upd(h.copy(handleRight = it == 1)) }
        }
    }
}

// ───────────────────────── INFO ─────────────────────────
private fun tempColor(c: Float): Color = when {
    c < 35f -> Good
    c < 42f -> Warm
    else -> Hot
}

@Composable
fun InfoScreen() {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("…") }
    var soc by remember { mutableStateOf("") }
    var cores by remember { mutableStateOf<List<Core>>(emptyList()) }
    var groups by remember { mutableStateOf<List<Pair<String, Rows>>>(emptyList()) }
    var gpu by remember { mutableStateOf<GpuData?>(null) }
    var stats by remember { mutableStateOf<LiveStats?>(null) }
    var cur by remember { mutableStateOf<List<Long?>>(emptyList()) }
    var zones by remember { mutableStateOf<List<Pair<String, Float>>>(emptyList()) }
    var ping by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(Unit) {
        cores = withContext(Dispatchers.IO) { Cpu.cores() }
        soc = withContext(Dispatchers.IO) { Cpu.soc() }
        name = withContext(Dispatchers.IO) { Info.marketName(ctx) }
        groups = withContext(Dispatchers.IO) { Info.deviceGroups(ctx) }
        gpu = withContext(Dispatchers.Default) { Gpu.query() }
    }
    LaunchedEffect(cores) {
        while (true) {
            val r = withContext(Dispatchers.IO) {
                Triple(
                    Stats.read(ctx, cores.map { it.id }),
                    cores.map { Cpu.curKhz(it.id) },
                    Power.snapshot(ctx).zones
                )
            }
            stats = r.first
            cur = r.second
            zones = r.third
            delay(1500)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            ping = withContext(Dispatchers.IO) { Ping.measure(0) }
            delay(3000)
        }
    }

    val s = stats
    Reveal(0) { Hero("📊", name, soc.ifEmpty { "SYSTEM MONITOR" }) }
    Reveal(1) {
        ActionCard(
            "Battery & Temp",
            if (s == null) "-" else "BAT ${s.level}%  TEMP ${Fmt.f1(s.tempC)}°C",
            Modifier.fillMaxWidth()
        ) {
            SectionTitle("BATTERY / TEMPERATURE")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RingGauge(
                    fraction = (s?.level ?: 0) / 100f,
                    color = if ((s?.level ?: 100) < 20) Hot else Good,
                    big = if (s == null) "…" else "${s.level}%",
                    small = "BATTERY",
                    size = 150.dp,
                    bigSize = 28
                )
                RingGauge(
                    fraction = (s?.tempC ?: 0f) / 60f,
                    color = tempColor(s?.tempC ?: 0f),
                    big = if (s == null) "…" else Fmt.f1(s.tempC) + "°",
                    small = "TEMP",
                    size = 150.dp,
                    bigSize = 28
                )
            }
        }
    }
    if (s != null) {
        Reveal(2) {
            ActionCard(
                "System",
                "RAM ${s.ramPct}%  PING ${ping ?: -1}ms  HZ ${s.hz}",
                Modifier.fillMaxWidth()
            ) {
                SectionTitle("SYSTEM")
                StatBar(
                    "RAM",
                    Fmt.f1(s.ramUsedGb) + " / " + Fmt.f1(s.ramTotalGb) + " GB  (" + s.ramPct + "%)",
                    s.ramPct / 100f
                )
                KV("PING", if (ping == null) "--" else ping.toString() + " ms")
                KV("REFRESH", s.hz.toString() + " Hz")
                KV("POWER", s.currentMa?.let { Fmt.f1(kotlin.math.abs(it) * s.voltMv / 1_000_000f) + " W" } ?: "--")
                KV("VOLTAGE", s.voltMv.toString() + " mV")
            }
        }
    }
    if (cores.isNotEmpty()) {
        Reveal(3) {
            GlowCard(Modifier.fillMaxWidth()) {
                SectionTitle("CPU CORES")
                cores.forEachIndexed { i, c -> CoreBar(c, cur.getOrNull(i)) }
                if (cur.isNotEmpty() && cur.all { it == null }) {
                    Spacer(Modifier.height(6.dp))
                    Txt("เครื่องนี้ไม่อนุญาตให้แอปทั่วไปอ่านความเร็วสดของ CPU", 12, Dim)
                }
            }
        }
    }
    val g = gpu
    if (g != null) {
        Reveal(4) {
            InfoCard(
                "GPU",
                listOf(
                    "Renderer" to g.renderer,
                    "Vendor" to g.vendor,
                    "OpenGL ES" to g.version,
                    "Vulkan" to Gpu.vulkan(ctx),
                    "Texture สูงสุด" to "${g.maxTex} px"
                )
            )
        }
    }
    Reveal(5) {
        if (zones.isNotEmpty()) {
            InfoCard(
                "THERMAL ZONES",
                zones.sortedByDescending { it.second }.map { it.first to Fmt.f1(it.second) + "°C" }
            )
        } else {
            NoteCard(
                "CPU / GPU LOAD & TEMP",
                "Android ไม่อนุญาตให้แอปทั่วไปอ่าน % โหลดและอุณหภูมิ CPU/GPU รวมถึง FPS ในเกมโดยตรง " +
                    "จึงแสดงเฉพาะค่าที่เครื่องเปิดให้อ่าน (ความเร็ว CPU, แบต, RAM, ping)"
            )
        }
    }
    groups.forEachIndexed { i, grp -> Reveal(6 + i) { InfoCard(grp.first, grp.second) } }
}
